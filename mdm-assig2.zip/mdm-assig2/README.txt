MDM Assignment 2

Marco Vassena, 4110161
Philipp Hausmann, 4003373

Report: doc/doc.pdf
Data:   data/...
Code:   src/...
